package inacaptemuco.com.inacapone;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ResultadoActivity extends AppCompatActivity {

    TextView txvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        txvResultado            = (TextView) findViewById(R.id.txv_resultado);

        Intent intento          = getIntent();

        Bundle datosRecibidos   = intento.getExtras();

        int edadRecibida        = datosRecibidos.getInt("p_edad");
        int pesoRecibido        = datosRecibidos.getInt("p_peso");
        String nombre = datosRecibidos.getString("p_nombre");

        int pesoIdeal           = edadRecibida * 2 +8;

        int diferenciaPeso = pesoRecibido-pesoIdeal;


        if (diferenciaPeso>0){

            txvResultado.setText("Peso ideal de "+nombre+" es: "+ pesoIdeal + "\tEl Crio está pasado "+diferenciaPeso+" kilos");

        }
        else if (diferenciaPeso<0){

            txvResultado.setText("Peso ideal de "+nombre+" es: "+ pesoIdeal + "\tEl Crio bajo peso por "+(diferenciaPeso*-1)+" kilos");
        }
    }
}
